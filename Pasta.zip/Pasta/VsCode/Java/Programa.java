public class Programa {
    public static void main(String[] args) {
        Banco meuBanco;
        meuBanco= new Banco();

        meuBanco.numConta = 18754;
        meuBanco.saldo= 1300;
        meuBanco.titularConta="Duke";
        
        System.out.println("Saldo aqui: " + meuBanco.saldo);
    }
}
