public class Banco {
 int numConta;
 String titularConta;
 double saldo;

 void sacar(double quantidade){
     double novoSaldo = this.saldo -  quantidade;
     this.saldo=novoSaldo;

 }
     
}

