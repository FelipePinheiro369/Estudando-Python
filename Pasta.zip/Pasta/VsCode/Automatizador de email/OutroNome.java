class OutroNome{
    public static void main(String[]args){
        //declaca a idade.
        int idade;
        idade=15;
        int quatro = 2+2;
        int tres = 5-2;
        int oito=4*2;
        int dezesseis =64/4;
        int um  = 5%2; 
        //5 dividido por 2 dá 2, e tem resto 1;
        // o operador % pega o resto da divisão inteira.


        // imprime a idade no cmd.
        System.out.println(idade);
        System.out.println(quatro);
        System.out.println(tres);
        System.out.println(oito);
        System.out.println(dezesseis);
        System.out.println(um);
    

    




    }

}
