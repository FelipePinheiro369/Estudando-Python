''' 
lista = [12,-2,4,8,29,45,78,36,-17,2,12,8,3,3,-52]
# funão que retorna o  maior elemento dentro de uma lista
def maior(lista):
    maior=0
    lista_interada =lista
    for i in range(0,len(lista)):
        if(lista_interada[i]>maior):
            maior=lista_interada[i]
    return maior
#Função que retorna o menor elemento dentro de uma lista
def menor(lista):
    menor =0
    for i in range(0, len(lista)):
        if(lista[i]<menor):
            menor=lista[i]
    return menor
# Função responsalvel de selecionar a quantidade de numeros pares dentro da lista
def par(lista):
    par=[]
    for i in range(0, len(lista)):
        if(lista[i]% 2 == 0):
          par.append(lista[i])
    return par
#Função que  busca no numero de ocorrencias do primeiro elemento da lista
def qtd_primeiro(lista):
    qtd=0
    primeiro =lista[0]
    for i in range(0,len(lista)):
        if(lista[i]==primeiro):
            qtd+=1
    return 'O numero de ocorrencia do primeiro elemento {} é {}'.format(primeiro,qtd)

# Função que retorna a media dos elementos da lista
def media(lista):
    qtd_elementos = 0
    soma_elementos = 0
    media=0
    for i in range(len(lista)):
        qtd_elementos+=1
        soma_elementos+=lista[i]

    return (soma_elementos)/qtd_elementos
#Função resposavel por somar todos os elementos negativos dentro de uma lista
def somaNegativo(lista):
    soma=0
    for i in range(len(lista)):
        if(lista[i]<0):
         soma+=lista[i]
    return 'Quantidade da soma de numeros negativos é {}'.format(soma)

print('Maior: {}'.format(maior(lista)))
print('Menor: {}'.format(menor(lista)))
print('Quantidade de numeros pares: {}'.format(par(lista)))
print(qtd_primeiro(lista))
print('Média: {:.2f}'.format(media(lista)))
print(somaNegativo(lista))
'''


def dados(nome, idade=None):
    if (idade is not None):
        return print('nome: {} \nidade: {} '.format(nome, idade))
    else:
        return print('nome: {} \nidade: não informada '.format(nome))


def soma(valor1, valor2):
    result = valor1 + valor2
    return result


def subtracao(valor1, valor2):
    result = valor1 - valor2
    return result


def multiplicacao(valor1, valor2):
    result = valor1 * valor2
    return result


def divisao(valor1, valor2):
    if (valor2 == 0):
        return 'Impossivel dividir por zero !!!'
    else:
        result = valor1 / valor2
        return result


def velocidade_media(velocidade, tempo):
    result = divisao(velocidade, tempo)
    return result


def calculadora(valor1, valor2):
    sum = ' soma: {} \n'.format(soma(valor1, valor2))
    sub = ' subtracao: {} \n'.format(subtracao(valor1, valor2))
    mult = ' multiplicacao {} \n'.format(multiplicacao(valor1, valor2))
    div = ' divisao {}'.format(divisao(valor1, valor2))
    return sum + sub + mult + div + '\n'


def teste(arg, *args):
    print('primeiro argumento normal: {}'.format(arg))
    for arg in args:
        print('outro argumento : {}'.format(arg))


def minha_funcao(**kwargs):
    for key, value in kwargs.items():
        print('{0} = {1}'.format(key, value))


def teste_args_kwargs(*args,**kwargs):
    for i in range(len(args)):
        print("args {} : {}".format(i+1,args[i]))
    for i in range(kwargs):
        print("{} {}".format(kwargs))



args = ('um', 2, 3, 4)
kwargs = {'args3': 3, 'args2': 'dois', 'args1': 'um', 'args4': 4}
teste_args_kwargs(*args)
teste_args_kwargs(**kwargs)
