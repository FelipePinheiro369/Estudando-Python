/**
 * MediaDeGastos
 */
public class MediaDeGastos {
public static void main(String[] args) {
boolean queroParar=false;
long f1=0;
long f2=1;
long fn=0;



do{
    fn=f1+f2;
System.out.println(fn);
}while(queroParar == false);

public cas

    }

}
