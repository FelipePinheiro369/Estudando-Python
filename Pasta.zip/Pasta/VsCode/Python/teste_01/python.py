

#print('\n Seu nome é {} e sua idade é {}'.format(nome,idade) )

numero = 42
chute =input("Digite um numero: ")

print(type(numero))
print(type(chute))
chute = int(chute)
acertou = numero ==chute
maior = chute > numero
menor = chute<numero
if acertou:
    print("Voce acertou! ")
elif maior:
    print("Você errou! O seu chute foi maior que o número secreto")
elif menor:
    print("Você errou! Seu chute foi menor que o número secreto")

