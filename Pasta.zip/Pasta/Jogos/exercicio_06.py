def teste_args_kwargs(*args,**kwargs):
     for arg in args:
      print("arg: {} ".format(arg))
     for  key, value in kwargs.items():
         print("{0}= {1} ".format(key,value))

args = ('um',2,3,4)
teste_args_kwargs(*args)
print()
kwargs = {'arg3': 3  , 'arg2' : 2,'arg1': 1 ,'arg0' : 0}
teste_args_kwargs(**kwargs)