
import  Menu
print('*************************')
print('*  Jogo da adivinhação  *')
print('*************************')
def jogar():
    numero_secreto = 42
    tentativa =0
    pontos = 1000
    pontos= int (pontos)
    nivel=int(input('Qual nivel você gostaria de jogar?'))
    if(nivel==1):
        tentativa=20
    elif(nivel==2):
        tentativa=10
    elif(nivel==3):
        tentativa=5
        print('-------')
    for rodada in range(1,tentativa+1):
        print('-------')
        if(pontos<=0):
            print('Sua pontuação é igaual a zero!!, Pontuação: {} '.format(pontos))
            break
        else:
            print('Tentativa {} de {}: \n Sua pontuação : {} '.format(rodada,tentativa,pontos))
            chute_str = input('Digite o seu número: ')
            print('Você digitou: ' ,chute_str)
            chute = int(chute_str)
            acertou = numero_secreto == chute
            maior =chute > numero_secreto
            menor =chute< numero_secreto
            if(acertou):
                print('Você acertou!')
                break
            elif(maior):
                print('Você errou!, O seu numero foi maior que o número secreto')
                pontos= pontos -(abs(chute-numero_secreto))
            elif(menor):
                print('Você errou! O seu chute foi menor que o numero secreto')
                pontos= pontos -(abs(chute-numero_secreto))
    print('Fim de Jogo! \n Sua pontuação final: {} '.format(pontos))






