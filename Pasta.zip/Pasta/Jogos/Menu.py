import forca
import adivinhacao


print('*********************************')
print('********* MENU DE JOGOS *********')
print("1. Adivinhação")
print("2. Forca")
escolha = int(input("qual jogo quer jogar?  Digite o número: "))



if(escolha== 1):
    adivinhacao.jogar()
elif escolha == 2:
    forca.jogar()

def jogar():
    return None