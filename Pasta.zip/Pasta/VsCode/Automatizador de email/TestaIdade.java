public class TestaIdade {
    public static void main(String[] args) {
        //imprime a idade.
        int idade =20;
        System.out.println(idade);
        // gera uma idade no ano seguinte.
        int idadeNoAnoQueVem;
        idadeNoAnoQueVem =idade+1;
        
        // imprime a idade. 
        System.out.println(idadeNoAnoQueVem);
         double pi =3.14;
          double x =5*10;
         boolean verdade =true;
         idade  =30;
         boolean menorDeIdade= idade<18;
         System.out.println(menorDeIdade);  
         char letra ='a';
         System.out.println(letra);



         System.out.printf("%f %f",pi,x);
    
    }
}
